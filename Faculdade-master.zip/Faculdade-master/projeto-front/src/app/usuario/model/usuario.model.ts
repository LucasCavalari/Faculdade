export class UsuarioModel {
    id: number = 0;
    nome: string = '';
    login: string = '';
    senha: string = '';
}