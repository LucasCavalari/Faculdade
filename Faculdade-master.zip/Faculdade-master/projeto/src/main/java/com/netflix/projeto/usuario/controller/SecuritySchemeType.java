package com.netflix.projeto.usuario.controller;

public interface SecuritySchemeType {
}
