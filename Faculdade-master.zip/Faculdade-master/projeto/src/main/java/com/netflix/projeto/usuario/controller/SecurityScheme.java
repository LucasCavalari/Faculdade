package com.netflix.projeto.usuario.controller;

public @interface SecurityScheme {
    String name();

    String scheme();
}
